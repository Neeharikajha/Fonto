README!

==================================

alphartype
support@alphartype.com
https://alphartype.com/

==================================


This font is free 100%
for personal use and commercial use
if you download on Dafont before 13 April 2024.

This font does not have complete glyphs, to get a font with glyphs with more complete punctuation or accents for multilingual needs you can buy it on our official website at https://alphartype.com/ and get a 30% discount by entering the SAVEBIG30 coupon on the checkout page.

If you cannot find the right license for your needs please Contact us by email at support@alphartype.com for a custom license or negotiation

Thank You


==================================