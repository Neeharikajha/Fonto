This font is for PERSONAL USE ONLY!

Please contact me before any commercial use.
My fonts for free use are allowed only in personal projects, and non-profit.
If you make money from using my fonts, Please purchase a commercial license.

Link to purchase full version and commercial license:
https://www.creativefabrica.com/product/spooky-dance/ref/244552/

Please visit our store for more great fonts:
https://www.creativefabrica.com/ref/244552/

For corporate license, contact me via email

Contact me at nirmalacreativestudio@gmail.com

If you want DONATE click here http://www.paypal.me/nirmalacreative
I really appreciate your donations.

Thank you :)