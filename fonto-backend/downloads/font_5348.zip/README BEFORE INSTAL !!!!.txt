English

By downloading and installing this font, you agree that the only font you install that you download is the "FREE PERSONAL USE" font that is "Non-Commercial".
and if you use the font on a "Commercial", there will be consequences for paying according to the license you are using.

Full License Here : 
- Creative Fabrica : https://www.creativefabrica.com/designer/dryy-type/
- Creative market : https://creativemarket.com/riandryana
for Donation Paypal : dryana19@gmail.com

1. This font is ONLY FOR PERSONAL USE.
2. NO COMMERCIAL USE ALLOWED.
3. You are REQUIRES A LICENSE for PROMOTIONAL or COMMERCIAL USE.
4. CONTACT ME before any Promotional or Commercial Use.

Support email:
Dryana19@gmail.com

Thanks



Indonesia

Dengan mengunduh dan menginstal font ini, Anda setuju bahwa satu-satunya font yang Anda unduh adalah font "Penggunaan Pribadi Gratis" yaitu "non-komersial".
Dan jika Anda menggunakan font pada "komersial", akan ada konsekuensi untuk membayar sesuai dengan lisensi yang Anda gunakan.

Lisensi Lengkap Di Sini:
- Creative Fabrica: https://www.creativefabrica.com/designer/dryy-type/
- Creative Market : https://creativeMarket.com/riandryana
untuk donasi paypal: dryana19@gmail.com

1. Font ini hanya untuk penggunaan pribadi.
2. Tidak ada penggunaan komersial yang diizinkan.
3. Anda memerlukan lisensi untuk penggunaan promosi atau komersial.
4. Hubungi saya sebelum penggunaan promosi atau komersial.

Dukungan Email:
Dryana19@gmail.com

Terima kasih

