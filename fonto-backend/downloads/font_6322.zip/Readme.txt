NOTE:

This font is for PERSONAL USE ONLY, NO COMMERCIAL USE ALLOWED!!!

If you want to purchase Full Version and Commercial Use here is the link :
bit.ly/3Jbh6Ir

For Corporate use you have to purchase Corporate license

Any donation are very appreciated. Paypal account for donation :
https://paypal.me/azzamridhamalik

If you need a custom license please contact us at
zarmatype@gmail.com

Please visit our store for more amazing fonts :
https://creativemarket.com/zarmatype?u=zarmatype

Follow our instagram for update : @zarma.type


Thank you