This font is PERSONAL USE only. If you want to use this font for COMMERCIAL
You need a commercial license that can be purchased here :

https://www.creativefabrica.com/designer/kammaqsum/

or contact by

email : kammaqsum@gmail.com

to DONATE click here https://www.paypal.me/MaqsumKamil

I really appreciate your donations.