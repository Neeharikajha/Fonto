Thank you for downloading,

NOTE: This demo font is for PERSONAL USE ONLY!
But If you want to DONATE click here :
https://paypal.me/rikkiibrahim. I really appreciate your donations.


If you need a commercial license, you can contact us at
rikki.ibrahim88@gmail.com

all forms of use of fonts without buying
the license must first comply with our settlement terms
purchases for commercial purposes and desires
subject to the Company License that we have made.

INDONESIA:

1. Font yang anda download ini hanya untuk "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit. Jika ingin menggunakan lisensi komersial silahkan menghubungi kami di : rikki.ibrahim88@gmail.com

2. Lisensi "Personal Use", tidak dibolehkan menggunakan atau memanfaatkan font untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.   

3. Pada penggunaan perusahaan silahkan membeli font ini dengan "lisensi corporate"

4. Apabila anda menggunakan "Personal use" untuk kebutuhan komersil tanpa izin dari kami / tanpa membeli terlebih dahulu makan kami selaku pemegang Hak Cipta Font akan dikenakan sanksi dengan biaya Coporate lisensi atau sesuai dengan ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta
yang berlaku di Republik Indonesia.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di : rikki.ibrahim88@gmail.com

Terima kasih.
