Bixbite Stone 2022 by Lemonthe
NOTE: This demo font is only for PERSONAL USE! But every donation is greatly appreciated.

Paypal account for donations: https://www.paypal.me/DwiAhidian

Commercial use is not allowed without prior written permission from the respective author. Please contact the author to ask for commercial licensing. Commercial use refers to usage in a business environment, including:
 
- business cards, logos, advertising, websites, mobile apps for companies
 - t-shirts, books, apparel that will be sold for money
 - flyers, posters for events that charge admission
 - freelance graphic design work
 - anything that will generate direct or indirect income

Commercial License
- https://www.myfonts.com/foundry/lemonthe/
- https://www.creativefabrica.com/designer/lemonthe
- https://fontbundles.net/lemonthe
- https://graphicriver.net/user/lemonthe/portfolio
- https://thehungryjpeg.com/store/lemonthe-type

thank you,
Lemonthe