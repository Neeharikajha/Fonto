
By installing or using this font, you are agree to the Product Usage Agreement:

This font is FOR PERSONAL USE ONLY. NO COMMERCIAL USE ALLOWED!

- link to buy full version and commercial license:

https://www.creativefabrica.com/product/retro-side/ref/208521/


- For Corporate use you have to purchase Corporate license.
- If you need A Custom License, please contact us at https://rvandtype.com/contact/

- Any donation are very appreciated. Paypal account for donation : https://www.paypal.me/RandiIrvan


Rvandtype Studio,
Thank You