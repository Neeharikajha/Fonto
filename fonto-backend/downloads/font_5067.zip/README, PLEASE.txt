This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-gallery/

Super Gallery: Where Playful Meets Sharp
Super Gallery is a font that bursts with personality, perfect for adding a touch of fun and whimsy to your designs.