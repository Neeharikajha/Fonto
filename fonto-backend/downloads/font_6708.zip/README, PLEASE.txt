This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-cosmic/

Forget boring fonts, Super Cosmic is here to save the day! This font is a superhero of the alphabet, with bold lines, cosmic curves, and enough sass to make any text feel superpowered. So, grab your cape and let your imagination take flight with Super Cosmic!

