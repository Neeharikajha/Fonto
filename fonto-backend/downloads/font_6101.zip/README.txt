PERSONAL USE LICENSE

!Thank you for downloading Prose Sans!


- This license grants you non-exclusive rights to use all fonts in this pack for PERSONAL projects.

- You may use the fonts to create prints and / or digital media for yourself.

- You may NOT resell, redistribute, share or embed the fonts in files you share with others.


*By downloading and/or installing this file you agree to this license.

** You may purchase the full version of this font -that includes all punctuation marks, multilingual characters and ligatures- from any one of these links:

https://fontbundles.net/ayca-atalay-creative

https://www.myfonts.com/foundry/ayca-atalay/

https://creativemarket.com/aycaatalay


—————————————————————————————————————————————————————————————————

Prose Sans is the intellectual property of Ayça Atalay.
© Ayça Atalay
