NOTE: This font is FREE FOR PERSONAL USE!  

Email : bluestype.studio123@gmail.com

Please visit our store for commercial use & full version : 
https://creativemarket.com/bluestype-studio
https://www.creativefabrica.com/designer/bluestype-studio/ref/235830/
https://fontbundles.net/bluestype-studio

Paypal account for donation : https://www.paypal.me/JefriDwiA

Thank You.