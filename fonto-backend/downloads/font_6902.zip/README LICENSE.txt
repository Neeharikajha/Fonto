Hello there!!!
Thank you for downloading FILLING IN LOVE font and taking time reading this note.

It is NOT FULL VERSION.

NOTE: This font is for PERSONAL USE ONLY. 

If you want to use for commercial purpose and full version, you can purchase here:
https://fontbundles.net/airotype/1133807-filling-in-love?ref=JZGY02


or message us ainrofi@gmail.com if you have any question.

Thank you so much...

Have fun and good luck!!!