Hello,

Thank for downloading Naturaliste.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NOT COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: https://crmrkt.com/ql0J01

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at Mozyenstudio@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/hasanpass
 


Follow our instagram for update : @Mozyen.studio
Thank you.
