# Lotion
A cute free font for programming!
![picture of code sample in Lotion typeface](img/sample.png "Picture of code
sample in Lotion typeface")

## Features
- Weights: Regular, SemiBold, Bold, Black
- Styles: Roman & *Italics*
- Now available as a variable font!

## Update: more western european language support
![picture of western european glyphs](img/western_european_glyphs.png "Picture of western european glyphs")
## Credits
Ligatures by @Nicell. Thank you!
