5 ThumpsUp Bold.otf ver 1.0


----------IMPORTANT NOTE----------

This version of 5 ThumpsUp Bold is absolutely free for personal, educational, non-profit, or charitable use. 
For commercial use, kindly donate me (pay as you want) as an appreciation. If you want to donate, my PayPal address is hellomonolab@gmail.com
Every donation is greatly appreciated. 

If you need further information,
kindly contact me at:
email address: hellomonolab@gmail.com



Thanks for being supportive,
MONOLAB

