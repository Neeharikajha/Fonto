NOTE: This demo font is for PERSONAL USE ONLY! 
But any donation are very appreciated.

- Paypal account for donation : https://paypal.me/rizkyale

- Link to purchase full version and commercial license:
https://crmrkt.com/QgeWBp

- If you need an extended license or corporate license, and you can also buy directly from me at a much cheaper price, please contact us
alemayorizky@gmail.com if you are interested