Note: This demo font is for PERSONAL USE ONLY!
--------------------------------------------------------

Link to purchase full version and commercial license :

-> https://fikryalstudio.com/product/tropical-county-modern-serif/

-> https://creativemarket.com/FikryalStudio/7222476-Tropical-County-Modern-Serif

--------------------------------------------------------
Browse More Font: https://fikryalstudio.com/
--------------------------------------------------------
Follow my Instagram for update: @fkryall
