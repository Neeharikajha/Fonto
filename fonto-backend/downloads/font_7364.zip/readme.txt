
----------------------------------------
Thank you for downloading Corwin College
----------------------------------------

Included in this download
- OpenType font file (.otf)
- This font download info doc. (.txt)
- Corwin College sample image (.png)

Glyphs characters included in this font:
a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J K L M N O P Q R S T U V W X Y Z 0 1 2 3 4 5 6 7 8 9 ¹ ² ³ ª º % $ € ¥ £ ¢ & * @ # | á â à ä å ã æ ç é ê è ë í î ì ï ı ñ ó ô ò ö õ ø œ š ß ú û ù ü ý ÿ ž Â À Ä Å Ã Æ Ç É Ê È Ë Í Î Ì Ï Ñ Ó Ô Ò Ö Õ Ø Œ Š Û Ù Ü Ý Ÿ , : ; - – — • . … “ ‘ ’ ‘  ‚  “ ” „ ‹ › « » / \ ? ! ¿ ¡ ( ) [ ] { } © ® § + × = _ ° 

If there's something in particular that you're struggling with, feel free to contact me on Friendlyfonts.com. I'd be happy to help you in whatever way I can.

Cheers Paul