This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-happy/

Introducing Super Happy: A Font Overflowing with Joy!

Imagine a font that bursts with sunshine and sparkles with delight. That's Super Happy! This exuberant typeface boasts playful, round curves and a bubbly personality that's guaranteed to bring a smile to your face.