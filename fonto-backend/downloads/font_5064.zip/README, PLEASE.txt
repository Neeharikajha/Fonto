This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-creamy/

Super Creamy: Dive into Delicious Design
Super Creamy is a font that’s as delightful as its name. It combines playful round letters with a groovy, hand-drawn twist, creating a design that’s both bold and fancy.