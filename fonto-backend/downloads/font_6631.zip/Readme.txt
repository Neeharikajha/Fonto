NOTE: This demo font is for PERSONAL USE ONLY! 
But any donation are very appreciated.

- Paypal account for donation : https://paypal.me/rizkyale

- Link to purchase full version and commercial license:
https://crmrkt.com/N1zxl5

- If you need an extended license or corporate license, please contact us
alemayorizky@gmail.com