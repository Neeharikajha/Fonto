NOTE: This demo font is FREE for PERSONAL USE ONLY!

For Commercial Use visit https://kulokale.com/product/aeroxys-font/

EMAIL SUPPORT: kulokalestudio@gmail.com

By installing or using this font, you agree to the Product Usage Agreement:

1. This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You have required a license for PROMOTIONAL or COMMERCIAL use. 
3. CONTACT ME before any Promotional or Commercial Use!

And follow my Instagram for update: @kulokalestudio

Regards,
Kulokale Studio