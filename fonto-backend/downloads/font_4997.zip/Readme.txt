ENGLISH
NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated.
- Paypal account for donation : https://paypal.me/dida21

- Link to purchase full version and commercial license:
https://www.creativefabrica.com/product/sidethree/ref/236854/

- If you need an extended license or corporate license, please contact us
ahweproject@gmail.com

Thank you.
====================
INDONESIA ( HARAP DIBACA !!! ):
Halo, terima kasih sudah mendownload font ini, Perlu diketahui bahwa :
- Font ini hanya untuk penggunaan PERSONAL saja, tidak untuk digunakan kebutuhan KOMERSIAL
- Jika anda ingin menggunakannya untuk kebutuhan komersial, anda harus membeli lisensi komersialnya terlebih dahulu
- Menggunakan font ini untuk kepentingan Komersial TANPA IZIN dari kami merupakan PELANGGARAN HAK CIPTA, dan akan kami kenakan biaya denda 25 juta .

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font diatas
Informasi tentang Lisensi, silahkan hubungi kami ahweproject@gmail.com    

Terimakasih
