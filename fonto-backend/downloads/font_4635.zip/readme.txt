if you want full version, please:

https://creativemarket.com/bentype/6811351-Berlings-Handmade-Crafted-Serif