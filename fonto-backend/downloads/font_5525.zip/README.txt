
By installing or using this font, you are agree to the Product Usage Agreement:

This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

link to purchase full version and commercial licence :

- https://rvandtype.com/sprinkles-cupcakes/

- For Corporate use you have to purchase Corporate license.
- If you need an extended license or corporate license, please contact me at rvandtype@gmail.com


Get FREE fonts For Commercial Use at:
- https://rvandtype.com/product-tag/freebies/
- https://www.creativefabrica.com/freebies/free-fonts/ref/208521/

- Any donation are very appreciated. Paypal account for donation : https://www.paypal.me/RandiIrvan


Rvandtype Studio,
Thank You