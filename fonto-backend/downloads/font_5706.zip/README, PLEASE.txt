This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-positive/

Introducing "Super Positive": A Headline Font with Infectious Optimism!
Super Positive is a bold and vibrant headline font designed to infuse your projects with infectious optimism. Its playful personality guarantees your words will grab attention and make a lasting impression.