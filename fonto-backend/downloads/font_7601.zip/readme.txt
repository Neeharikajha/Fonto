This font was inspired by the 7 x 11 pixel font (or 8 x 12 if you include the drop shadow) as seen in F-Zero for the SNES. I've also created my own versions of the missing characters and symbols. You can also use it as a pixel font if you reduce the size and turn off anti-aliasing or set text rendering to nearest neighbor.

Donation are greatly appreciated
https://www.paypal.me/midiman10