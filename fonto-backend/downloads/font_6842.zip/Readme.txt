Note of the author
This is font free for PERSONAL USE
If you need for commercial use, you can buy the license here :

*****link shop*****

to DONATE click here: https://www.paypal.me/dida21
Or contact me to my instagram -> https://www.instagram.com/lettersweetstudio/
Thank you :)