Note: This demo font is for PERSONAL USE ONLY!
--------------------------------------------------------

Link to purchase full version and commercial license :

-> https://fikryalstudio.com/product/queensides-elegant-sans/
--------------------------------------------------------
Browse More Font: https://fikryalstudio.com/
--------------------------------------------------------
Follow my Instagram for update: fkryall
