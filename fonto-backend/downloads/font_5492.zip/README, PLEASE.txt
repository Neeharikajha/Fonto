This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-cedar/

Super Cedar: This bold serif font adds a touch of whimsy to your headlines. It's perfect for making a statement that's both impactful and lighthearted.